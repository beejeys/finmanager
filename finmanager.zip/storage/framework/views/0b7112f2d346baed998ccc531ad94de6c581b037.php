

<?php $__env->startSection('content'); ?>
<h1>Welcome to Benbelon</h1>

<form action="" method="GET" >
    <p><input type="date" name="date" value="<?php echo e(request()->date); ?>" /> <input type="submit" value="Submit" /></p>
</form>

<table cellpadding="10" ccellspacing="0" border="1">
    <tr>
        <th>Date</th>
        <th>Title</th>
        <th>Expense</th>
        <th>Income</th>
        <th>Account</th>
        <th>Balance</th>
    </tr>
    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(date('d M Y',strtotime($transaction->happened_at))); ?></td>
        <td><?php echo e($transaction->title); ?></td>
        <td><?php if($transaction->type=='expense'): ?> <?php echo e($transaction->amount); ?> <?php endif; ?></td>
        <td><?php if($transaction->type=='income'): ?> <?php echo e($transaction->amount); ?> <?php endif; ?></td>
        <td><?php echo e($transaction->title); ?></td>
        <td></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\finmanager\resources\views/pages/index.blade.php ENDPATH**/ ?>